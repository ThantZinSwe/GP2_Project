<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="/library/reset.css">
    <link rel="stylesheet" href="/auth/style.css">
    <link rel="stylesheet" href="/library/fontawesome/css/all.min.css">
</head>
<body>
<div class="sign-box">
    <h1 class="sign-title">Login</h1>
    <form action="" class="sign-form">
      
      <div class="conmon-req pro-email">
      <i class="fa-solid fa-envelope"></i>
        <input type="email" placeholder="Email" required name="email">
        
      </div>
      <div class="conmon-req pro-pass">
      <i class="fa-solid fa-lock"></i>
        <input type="password" placeholder="Password" required name="password">
        
      </div>
     
      <a href="#">Forgot Password?</a><br>
      <input type="submit" value="Login" class="pro-submit">
    </form>
  </div>
</body>
</html>